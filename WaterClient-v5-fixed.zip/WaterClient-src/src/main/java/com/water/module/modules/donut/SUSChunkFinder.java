package com.water.module.modules.donut;

import com.water.module.Category;
import com.water.module.Module;
import com.water.module.setting.Setting;
import com.water.render.FontRenderer;
import com.water.render.ProjectedPoint;
import com.water.render.Render3D;
import com.water.render.RenderUtils;
import com.water.render.ShapeBatch;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

/**
 * Amethyst-based SUS Chunk Finder (Donut style).
 * Shows stable % labels without flickering.
 */
public final class SUSChunkFinder extends Module {
   public static SUSChunkFinder INSTANCE;

   public final Setting<Integer> scanRadius = new Setting<>("Scan Radius", 1, 1, 5);
   public final Setting<Integer> clusterThreshold = new Setting<>("Sim Chunks", 10, 1, 10);
   public final Setting<Integer> minCount = new Setting<>("Min Amethyst", 5, 1, 40);
   public final Setting<Color> fillColor = new Setting<>("Fill Color", new Color(160, 60, 220, 45));
   public final Setting<Integer> fillAlpha = new Setting<>("Fill Alpha", 45, 0, 255);
   public final Setting<Boolean> showInfo = new Setting<>("Show % & Count", true);
   public final Setting<Boolean> showOutline = new Setting<>("Outline", true);

   public final Map<ChunkPos, Integer> amethystCounts = new ConcurrentHashMap<>();
   public volatile Set<ChunkPos> amethystRenderCache = Collections.emptySet();
   public ExecutorService scanExec;
   public final AtomicBoolean scanning = new AtomicBoolean(false);
   public int tickCount = 0;
   private final ProjectedPoint projected = new ProjectedPoint();

   public SUSChunkFinder() {
      super("Amethyst Sus Finder", Category.DONUT);
      INSTANCE = this;
      this.addSetting(this.scanRadius);
      this.addSetting(this.clusterThreshold);
      this.addSetting(this.minCount);
      this.addSetting(this.fillColor);
      this.addSetting(this.fillAlpha);
      this.addSetting(this.showInfo);
      this.addSetting(this.showOutline);
   }

   @Override
   public void onEnable() {
      this.clearScanState();
   }

   @Override
   public void onDisable() {
      this.clearScanState();
      if (this.scanExec != null) this.scanExec.shutdownNow();
   }

   public void clearScanState() {
      this.amethystCounts.clear();
      this.amethystRenderCache = Collections.emptySet();
      this.tickCount = 0;
      this.scanning.set(false);
   }

   @Override
   public void onTick() {
      if (mc.world == null || mc.player == null) return;

      ChunkPos origin = mc.player.getChunkPos();
      int radius = this.scanRadius.getValue() * 5;

      this.amethystCounts.entrySet().removeIf(e ->
         Math.abs(e.getKey().x - origin.x) > radius + 2 || Math.abs(e.getKey().z - origin.z) > radius + 2);

      if (++this.tickCount % 10 != 0) return; // slower scan = less flicker
      if (!this.scanning.compareAndSet(false, true)) return;

      if (this.scanExec == null || this.scanExec.isShutdown()) {
         this.scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "amethyst-sus-scan");
            t.setDaemon(true);
            return t;
         });
      }

      List<ChunkPos> positions = new ArrayList<>();
      List<WorldChunk> chunks = new ArrayList<>();
      int scanR = this.scanRadius.getValue() * 5;
      for (int dx = -scanR; dx <= scanR; dx++) {
         for (int dz = -scanR; dz <= scanR; dz++) {
            ChunkPos cp = new ChunkPos(origin.x + dx, origin.z + dz);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z, false);
            if (wc != null && !wc.isEmpty()) {
               positions.add(cp);
               chunks.add(wc);
            }
         }
      }

      int min = this.minCount.getValue();
      int cluster = this.clusterThreshold.getValue();
      ChunkPos originFinal = origin;

      this.scanExec.submit(() -> {
         try {
            HashMap<ChunkPos, Integer> countMap = new HashMap<>();
            HashMap<ChunkPos, Integer> amethystMap = new HashMap<>();

            for (int i = 0; i < positions.size(); i++) {
               ChunkPos cp = positions.get(i);
               int count = this.countAmethyst(chunks.get(i));
               countMap.put(cp, count);
               if (count >= min) {
                  amethystMap.put(cp, count);
               }
            }

            Set<ChunkPos> top = this.pickTopChunks(amethystMap, originFinal, cluster);

            this.amethystCounts.clear();
            this.amethystCounts.putAll(countMap);
            // atomic swap — no mid-frame clear of visible set
            this.amethystRenderCache = Collections.unmodifiableSet(top);
         } catch (Exception ignored) {
         } finally {
            this.scanning.set(false);
         }
      });
   }

   public Set<ChunkPos> pickTopChunks(Map<ChunkPos, Integer> map, ChunkPos origin, int limit) {
      ArrayList<Map.Entry<ChunkPos, Integer>> list = new ArrayList<>(map.entrySet());
      list.sort((a, b) -> {
         int cmp = Integer.compare(b.getValue(), a.getValue());
         if (cmp != 0) return cmp;
         int dxA = a.getKey().x - origin.x, dzA = a.getKey().z - origin.z;
         int dxB = b.getKey().x - origin.x, dzB = b.getKey().z - origin.z;
         return Integer.compare(dxA * dxA + dzA * dzA, dxB * dxB + dzB * dzB);
      });

      LinkedHashSet<ChunkPos> result = new LinkedHashSet<>();
      int max = Math.max(1, limit);
      for (Map.Entry<ChunkPos, Integer> e : list) {
         if (result.size() >= max) break;
         result.add(e.getKey());
      }
      return result;
   }

   public int countAmethyst(WorldChunk chunk) {
      int count = 0;
      ChunkSection[] sections = chunk.getSectionArray();
      int bottom = chunk.getBottomY();

      for (int s = 0; s < sections.length; s++) {
         int sectionY = bottom + s * 16;
         if (sectionY > 32) break;

         ChunkSection section = sections[s];
         if (section == null || section.isEmpty() || !section.hasAny(this::isAmethyst)) continue;

         for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
               for (int z = 0; z < 16; z++) {
                  if (this.isAmethyst(section.getBlockState(x, y, z))) {
                     count++;
                  }
               }
            }
         }
      }
      return count;
   }

   public boolean isAmethyst(BlockState state) {
      return state.isOf(Blocks.AMETHYST_CLUSTER) || state.isOf(Blocks.AMETHYST_BLOCK)
         || state.isOf(Blocks.BUDDING_AMETHYST)
         || state.isOf(Blocks.SMALL_AMETHYST_BUD)
         || state.isOf(Blocks.MEDIUM_AMETHYST_BUD)
         || state.isOf(Blocks.LARGE_AMETHYST_BUD);
   }

   public int calcPercent(int amethystCount) {
      return (int) Math.min(100, Math.max(0, Math.round(amethystCount * 1.25)));
   }

   @Override
   public void onRender(MatrixStack matrices, float tickDelta) {
      if (mc.world == null || mc.player == null) return;
      Set<ChunkPos> cache = this.amethystRenderCache;
      if (cache.isEmpty()) return;

      Camera camera = RenderUtils.getCamera();
      if (camera == null) return;
      Vec3d cam = RenderUtils.getCameraPos(camera);

      // fixed height band near y=47 (geode level) — no flash animation
      double boxY = 47.0 - cam.y;
      double boxY2 = boxY + 0.15;

      Color base = this.fillColor.getValue();
      Color fill = new Color(base.getRed(), base.getGreen(), base.getBlue(), this.fillAlpha.getValue());
      Color outline = new Color(base.getRed(), base.getGreen(), base.getBlue(), Math.min(255, this.fillAlpha.getValue() + 100));

      matrices.push();
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      ShapeBatch batch = RenderUtils.beginShapeBatch(matrices);

      for (ChunkPos cp : cache) {
         double x1 = (cp.x << 4) - cam.x;
         double z1 = (cp.z << 4) - cam.z;
         batch.renderFilledBox(x1, boxY, z1, x1 + 16.0, boxY2, z1 + 16.0, fill);
         if (this.showOutline.getValue()) {
            batch.renderOutlineBox(x1, boxY, z1, x1 + 16.0, boxY2, z1 + 16.0, outline);
         }
      }

      batch.flush();
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      matrices.pop();
   }

   public static void renderHud(DrawContext context, float tickDelta) {
      SUSChunkFinder self = INSTANCE;
      if (self == null || !self.isEnabled() || !self.showInfo.getValue()) return;
      Set<ChunkPos> cache = self.amethystRenderCache;
      if (cache.isEmpty()) return;

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.player == null || mc.world == null) return;

      double textY = 48.5;

      for (ChunkPos cp : cache) {
         double worldX = (cp.x << 4) + 8.0;
         double worldZ = (cp.z << 4) + 8.0;

         if (!Render3D.projectToPoint(Render3D.modelViewMatrix, Render3D.projectionMatrix, worldX, textY, worldZ, self.projected)) {
            continue;
         }
         if (!self.projected.visible) continue;

         int count = self.amethystCounts.getOrDefault(cp, 0);
         int percent = self.calcPercent(count);

         // marker: amethyst symbol
         String line1 = "\u2726 " + percent + "%"; // star/diamond marker
         String line2 = "Am " + count;

         float x = (float) self.projected.x;
         float y = (float) self.projected.y;

         int w1 = FontRenderer.INSTANCE.getWidth(line1);
         int w2 = FontRenderer.INSTANCE.getWidth(line2);

         int color = percent >= 80 ? 0xFFFF5555 : (percent >= 50 ? 0xFFFFAA00 : 0xFFCC88FF);

         FontRenderer.INSTANCE.drawString(context, line1, x - w1 / 2f + 1, y + 1, 0xFF000000);
         FontRenderer.INSTANCE.drawString(context, line1, x - w1 / 2f, y, color);
         FontRenderer.INSTANCE.drawString(context, line2, x - w2 / 2f + 1, y + 11, 0xFF000000);
         FontRenderer.INSTANCE.drawString(context, line2, x - w2 / 2f, y + 10, 0xFFFFFFFF);
      }
   }
}
